### Translations
1. 🇬🇧 English
2. 🇭🇺 Hungarian
3. 🇳🇱 Dutch by [tlmnot](https://github.com/tlmnot)
4. 🇨🇿 Czech by [tomo90](https://github.com/tomo90)
5. 🇯🇵 Japanese by [kato-k](https://github.com/kato-k)
6. 🇦🇩 Catalan by retiolus
7. 🇵🇱 Polish by [ZiomaleQ](https://github.com/ZiomaleQ)
8. 🇸🇰 Slovak by [Juraj Liso](https://github.com/LiJu09)
9. 🇮🇩 Indonesian by [zmni](https://github.com/zmni)
10. 🇮🇹 Italian by Luigi Sforza
11. 🇪🇸 Spanish by Jose Casas
12. 🇹🇷 Turkish by Helpful User
13. 🇺🇦 Ukrainian by Alex Shpak
14. 🇩🇰 Danish by [shoddysheep](https://github.com/shoddysheep)
15. 🇸🇪 Swedish by Erik Lindström
16. 🇷🇺 Russian by Denis Bondarenko
17. 🇫🇷 French by Arnaud Dieumegard, [Co-7](https://github.com/Co-7)
18. 🇧🇷 Portuguese (Brazil) by [fabianski7](https://github.com/fabianski7)
19. 🇵🇹 Portuguese (Portugal) by [joaopmatos](https://github.com/joaopmatos)
20. 🇳🇴 Norwegian (Bokmål) by Fredrik Magnussen, [Erik Thom](https://github.com/erikthm)
21. 🇳🇴 Norwegian (Nynorsk) by [Erik Thom](https://github.com/erikthm)
22. 🇵🇭 Tagalog by Isaiah Collins Abetong
23. 🇨🇳 Chinese (Simplified) by [Austin Huang](https://github.com/austinhuang0131)
24. 🇩🇪 German by Maximilian Braunschmied, [jonas-haeusler](https://github.com/jonas-haeusler), [samuel141](https://github.com/samuel141)