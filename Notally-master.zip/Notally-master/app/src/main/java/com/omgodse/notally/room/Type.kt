package com.omgodse.notally.room

enum class Type { NOTE, LIST }