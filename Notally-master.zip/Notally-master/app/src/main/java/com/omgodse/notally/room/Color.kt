package com.omgodse.notally.room

enum class Color {
    DEFAULT,
    CORAL,
    ORANGE,
    SAND,
    STORM,
    FOG,
    SAGE,
    MINT,
    DUSK,
    FLOWER,
    BLOSSOM,
    CLAY
}