package com.omgodse.notally.room

enum class ViewType { NOTE, HEADER }